<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%@ page import="java.sql.*" %>
<%@ page import="util.DBConnection" %>

<%
if(session.getAttribute("user") == null){
response.sendRedirect("login.jsp");
return;
}

String username = (String)session.getAttribute("user");
%>

<html>
<head>
    <meta charset="UTF-8">
    <title>My Cart</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%@ include file="navbar.jsp" %>

<h1>🛒 My Cart</h1>

<table border="1">
<tr>
    <th>Product Name</th>
    <th>Description</th>
    <th>Price</th>
    <th>Action</th>
</tr>

<%
double total = 0;

try{
Connection con = DBConnection.getConnection();


String sql =
    "SELECT p.* FROM cart c " +
    "JOIN products p ON c.product_id = p.id " +
    "WHERE c.username=?";

PreparedStatement ps = con.prepareStatement(sql);
ps.setString(1, username);

ResultSet rs = ps.executeQuery();

while(rs.next()){
    total += rs.getDouble("price");


%>

<tr>
    <td><%= rs.getString("name") %></td>
    <td><%= rs.getString("description") %></td>
    <td>₹<%= rs.getDouble("price") %></td>
    <td>
            <a href="RemoveFromCartServlet?id=<%= rs.getInt("id") %>">
                Remove
            </a>
        </td>
</tr>

<%
}
}
catch(Exception e){
out.println(e.getMessage());
}
%>

</table>

<h2>Total: ₹<%= total %></h2>

</body>
</html>
