<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<head>
    <title>index</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">

    <h1>🛒 ShopSphere</h1>

    <p>Your one-stop online shopping destination.</p>

    <a href="login.jsp">Login</a>
    <a href="register.jsp">Register</a>
    <a href="products.jsp">View Products</a>

</div>
</body>