
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<div class="navbar">
    <a href="index.jsp" class="logo">
        🛒 ShopSphere
    </a>


<div class="nav-links">
    <a href="index.jsp">Home</a>
    <a href="products.jsp">Products</a>

    <%
        if(session.getAttribute("user") != null){
    %>
        <a href="cart.jsp">Cart</a>
        <a href="LogoutServlet">Logout</a>
    <%
        } else {
    %>
        <a href="login.jsp">Login</a>
        <a href="register.jsp">Register</a>
    <%
        }
    %>
</div>

</div>
