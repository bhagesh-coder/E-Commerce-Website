<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*" %>
<%@ page import="util.DBConnection" %>

<%
if(session.getAttribute("user") == null){
response.sendRedirect("login.jsp");
return;
}

String user = (String) session.getAttribute("user");
%>

<html>
<head>
    <meta charset="UTF-8">
    <title>Products - ShopSphere</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<%@ include file="navbar.jsp" %>

<div class="hero">
    <h1>🛍 Our Products</h1>
    <h3>Welcome, <%= user %></h3>
</div>

<div class="product-container">

<%
try{
Connection con = DBConnection.getConnection();


Statement st = con.createStatement();

ResultSet rs =
        st.executeQuery("SELECT * FROM products");

while(rs.next()){


%>


<div class="product-card">

    <div class="product-icon">
    <%
    String name = rs.getString("name");

    if(name.equalsIgnoreCase("Laptop")){
    %>
    💻
    <%
    }else if(name.equalsIgnoreCase("Phone")){
    %>
    📱
    <%
    }else if(name.equalsIgnoreCase("Headphones")){
    %>
    🎧
    <%
    }else{
    %>
    📦
    <%
    }
    %>
    </div>

    <h2><%= rs.getString("name") %></h2>

    <p>
        <%= rs.getString("description") %>
    </p>

    <h3 class="price">
        &#8377;<%= rs.getDouble("price") %>
    </h3>

    <a class="btn"
       href="AddToCartServlet?id=<%= rs.getInt("id") %>">
        Add To Cart
    </a>

</div>


<%
}

}catch(Exception e){
out.println("<h3>"+e.getMessage()+"</h3>");
}
%>

</div>

</body>
</html>
