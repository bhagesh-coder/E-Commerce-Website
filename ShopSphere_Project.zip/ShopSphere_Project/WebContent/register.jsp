<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<h2>Register Page</h2>

<html>
<head>
    <title>register</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<%@ include file="navbar.jsp" %>
<h2>Register</h2>

<form action="RegisterServlet" method="post">

    Name:
    <input type="text" name="name"><br><br>

    Email:
    <input type="email" name="email"><br><br>

    Password:
    <input type="password" name="password"><br><br>

    <input type="submit" value="Register">

</form>

</body>
</html>