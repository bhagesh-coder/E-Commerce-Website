CREATE DATABASE ecommerce;
CREATE DATABASE IF NOT EXISTS ecommerce;
USE ecommerce;

CREATE TABLE users (
                       id INT PRIMARY KEY AUTO_INCREMENT,
                       name VARCHAR(100) NOT NULL,
                       email VARCHAR(100) UNIQUE NOT NULL,
                       password VARCHAR(255) NOT NULL
);

CREATE TABLE products (
                          id INT PRIMARY KEY AUTO_INCREMENT,
                          name VARCHAR(100) NOT NULL,
                          description VARCHAR(255),
                          price DECIMAL(10,2) NOT NULL
);

INSERT INTO products(name, description, price) VALUES
                                                   ('Laptop', 'Gaming Laptop', 75000.00),
                                                   ('Phone', 'Android Phone', 25000.00),
                                                   ('Headphones', 'Wireless Headphones', 3000.00);