package controller;

import util.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;


public class AddToCartServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        try {
            HttpSession session = request.getSession();

            String username =
                    (String) session.getAttribute("user");

            int productId =
                    Integer.parseInt(request.getParameter("id"));

            Connection con =
                    DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(
                            "INSERT INTO cart(username, product_id) VALUES(?,?)");

            ps.setString(1, username);
            ps.setInt(2, productId);

            ps.executeUpdate();

            response.sendRedirect("products.jsp");

        } catch(Exception e) {
            throw new ServletException(e);
        }
    }
}