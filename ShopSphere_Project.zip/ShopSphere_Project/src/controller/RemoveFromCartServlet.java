package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.DBConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class RemoveFromCartServlet extends HttpServlet {


    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        try {

            HttpSession session = request.getSession();
            String username =
                    (String) session.getAttribute("user");

            int productId =
                    Integer.parseInt(request.getParameter("id"));

            Connection con =
                    DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(
                            "DELETE FROM cart WHERE username=? AND product_id=? LIMIT 1"
                    );

            ps.setString(1, username);
            ps.setInt(2, productId);

            ps.executeUpdate();

            response.sendRedirect("cart.jsp");

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }


}
